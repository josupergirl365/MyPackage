# MyPackage
This library was created as en example of how to publish your own Python package

# How to install
....